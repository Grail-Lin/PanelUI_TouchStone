// 最後編輯 2023-10-29 by ShinWei Chiou
// 初版

// 最後編輯 2024-1-05 by ShinWei Chiou
// 更改名稱

// 最後編輯 2024-1-12 by ShinWei Chiou
// 新增旗標


//------------------------------------------------------------------------------------------------
String RespondCharTemp[4];  // 接收暫存資料矩陣
String ReceiverCharTemp[4]; // 傳送暫存資料矩陣

const unsigned int OLED_Display_Change_Time = 100;  // 更換 OLED 顯示時間
unsigned int OLED_Display_Change_Counter = 0;

boolean Cartridge_Rotation_Zero_Position_Flag = 0;

boolean Cup_Driver_Back_Flag = 0;
boolean Cup_Driver_Front_Flag = 0;

boolean Rocker_Arm_Release_Flag = 0;
boolean Rocker_Arm_Contact_Flag = 0;

boolean Optical_Position_Up_Flag = 0;
boolean Optical_Position_Down_Flag = 0;

boolean Reserves_Motor_SW1_Flag = 0;
boolean Reserves_Motor_SW2_Flag = 0;

boolean Door_Open_Flag = 0;
boolean Door_Close_Flag = 0;

boolean Cartridge_Roller_Back_Flag = 0;
boolean Cartridge_Roller_Front_Flag = 0;

boolean Vertical_Position_Top_Flag = 0;
boolean Vertical_Position_Middle_Flag = 0;
boolean Vertical_Position_Bottom_Flag = 0;

boolean BLDC_CW_Running = 0;
boolean BLDC_CCW_Running = 0;



// Cartridge Rotation ------------------
#define CartridgeRotationP_PIN      61
#define CartridgeRotationN_PIN      60
#define QRE1113_Sensor1_PIN         62
#define QRE1113_Sensor2_PIN         63

// Cup Driver --------------------------
#define CupDriverP_PIN              65
#define CupDriverN_PIN              64
#define CupDriverLSW1_PIN           66
#define CupDriverLSW2_PIN           67

// Rocker Arm --------------------------
#define RockerArmP_PIN              69
#define RockerArmN_PIN              68
#define RockerArmLSW1_PIN           22
#define RockerArmLSW2_PIN           23

// Optical Position --------------------
#define OpticalPositionP_PIN        25
#define OpticalPositionN_PIN        24
#define OpticalPositionLSW1_PIN     26
#define OpticalPositionLSW2_PIN     27

// Reserves Motor ----------------------
#define ReservesMotorP_PIN          29
#define ReservesMotorN_PIN          28
#define ReservesMotorLSW1_PIN       39
#define ReservesMotorLSW2_PIN       14

// Door --------------------------------
#define DoorP_PIN                   30
#define DoorN_PIN                   15
#define DoorLSW1_PIN                31
#define DoorLSW2_PIN                32

// Cartridge Roller --------------------
#define CartridgeRollerP_PIN        34
#define CartridgeRollerN_PIN        33
#define CartridgeRollerLSW1_PIN     35
#define CartridgeRollerLSW2_PIN     36

// Vertical Position -------------------
#define VerticalPositionP_PIN       8
#define VerticalPositionN_PIN       9
#define VerticalPositionPH_PIN      53
#define VerticalPositionLSW1_PIN    7
#define VerticalPositionLSW2_PIN    6

// BLDC Motor --------------------------
#define BLDC_Speed_PIN              5
#define BLDC_RPM_PIN                19
#define BLDC_CCW_PIN                18

// Vacuum Pump & Valve -----------------
#define VacuumAirPump_PIN           11
#define AirValve1_PIN               42
#define AirValve2_PIN               43
#define AirValve3_PIN               44
#define AirValve4_PIN               45
#define AirValve5_PIN               46
#define AirValve6_PIN               47

// Reserves Pump & Valve ---------------
#define ReservesAirPump_PIN         10
#define ReservesValve1_PIN          48
#define ReservesValve2_PIN          49

// Heater ------------------------------
#define HeaterNTC_PIN               A0
#define Heater_PIN                  2

// Reserves Heater ---------------------
#define ReservesHeaterNTC_PIN       A1
#define ReservesHeater_PIN          3

// Thermoelectric Chip -----------------
#define ThermoelectricNTC1_PIN      A2
#define ThermoelectricNTC2_PIN      A3
#define ThermoelectricChip_PIN      4

// Water Cooler ------------------------
#define WaterCoolerNTC1_PIN         A4
#define WaterCoolerNTC2_PIN         A5
#define WaterCoolerFan_PIN          40
#define WaterCoolerPump_PIN         41

// System Dissipation ------------------
#define DS18B20_PIN                 38
#define SystemDissipationFan_PIN    37

// Optical Dissipation -----------------
#define OpticalDissipationFan_PIN   12

// Other -------------------------------
#define Buzzer_PIN                  13



//------------------------------------------------------------------------------------------------
#include <SmoothThermistor.h>

/*
            AREF        Analog Pin
             |              |
      5.0V |-+---/\/\/\-----+-----/\/\/\-----| GND
                   ^                ^
           100K thermistor      10K resistor

  SmoothThermistor smoothThermistor(A0,              // the analog pin to read from
                                   ADC_SIZE_10_BIT, // the ADC size
                                   10000,           // the nominal resistance
                                   10000,           // the series resistance
                                   3950,            // the beta coefficient of the thermistor
                                   25,              // the temperature for nominal resistance
                                   10);             // the number of samples to take for each measurement
               ADC_SIZE_8_BIT
               ADC_SIZE_10_BIT
               ADC_SIZE_12_BIT
               ADC_SIZE_16_BIT
*/

#define THERMISTOR_NOMINAL    105000   // NTC 100K ( 降低設定值 可調降溫度讀取數值 +-500 )
#define TEMP_SERIESRESISTOR   9900    // 10K the value of the 'other' resistor
#define TEMPERATURE_NOMINAL   25      // Temp. for nominal resistance (almost always 25 C)
#define TEMP_NUMSAMPLES       10      // how many samples to take and average, more takes longer
#define TEMP_BCOEFFICIENT     3950    // The beta coefficient of the thermistor (usually 3000-4000)

// create a SmoothThermistor instance, reading from analog pin
SmoothThermistor NTC_Heater_Thermistor(HeaterNTC_PIN, ADC_SIZE_10_BIT, THERMISTOR_NOMINAL, TEMP_SERIESRESISTOR, TEMP_BCOEFFICIENT, TEMPERATURE_NOMINAL, TEMP_NUMSAMPLES);
SmoothThermistor NTC_ReservesHeate_Thermistor(ReservesHeaterNTC_PIN, ADC_SIZE_10_BIT, THERMISTOR_NOMINAL, TEMP_SERIESRESISTOR, TEMP_BCOEFFICIENT, TEMPERATURE_NOMINAL, TEMP_NUMSAMPLES);
SmoothThermistor NTC_TEC1_Thermistor(ThermoelectricNTC1_PIN, ADC_SIZE_10_BIT, THERMISTOR_NOMINAL, TEMP_SERIESRESISTOR, TEMP_BCOEFFICIENT, TEMPERATURE_NOMINAL, TEMP_NUMSAMPLES);
SmoothThermistor NTC_TEC2_Thermistor(ThermoelectricNTC2_PIN, ADC_SIZE_10_BIT, THERMISTOR_NOMINAL, TEMP_SERIESRESISTOR, TEMP_BCOEFFICIENT, TEMPERATURE_NOMINAL, TEMP_NUMSAMPLES);
SmoothThermistor NTC_WaterCooler1_Thermistor(WaterCoolerNTC1_PIN, ADC_SIZE_10_BIT, THERMISTOR_NOMINAL, TEMP_SERIESRESISTOR, TEMP_BCOEFFICIENT, TEMPERATURE_NOMINAL, TEMP_NUMSAMPLES);
SmoothThermistor NTC_WaterCooler2_Thermistor(WaterCoolerNTC2_PIN, ADC_SIZE_10_BIT, THERMISTOR_NOMINAL, TEMP_SERIESRESISTOR, TEMP_BCOEFFICIENT, TEMPERATURE_NOMINAL, TEMP_NUMSAMPLES);

float NTC_Heater_NowValue;
float NTC_ReservesHeate_NowValue;
float NTC_TEC1_NowValue;
float NTC_TEC2_NowValue;
float NTC_WaterCooler1_NowValue;
float NTC_WaterCooler2_NowValue;
